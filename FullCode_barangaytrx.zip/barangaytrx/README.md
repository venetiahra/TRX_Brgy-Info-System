# Barangay Information System - Barangay TRX (Full Updated Project)

This full package includes:
- Dashtreme-style **admin dashboard** with **sidebar navigation**
- Separate **client/public portal** with a **top header navbar**
- Resident CRUD
- Certificate request / preview / print / history
- Favicon and integrated Barangay TRX seal branding
- Dashboard charts using real database data

## Setup in XAMPP
1. Copy the folder into `C:/xampp/htdocs/`
2. Start Apache and MySQL in XAMPP
3. Import `database/barangay_db.sql`
4. Open the project in the browser
5. If no users exist yet, go to `/auth/register_admin.php`
6. Suggested admin credentials: `admin / admin123`

## Important pages
- Admin login: `/auth/login.php`
- Admin dashboard: `/dashboard.php`
- Client portal: `/client/index.php`

## Branding
- `assets/favicon.ico`
- `assets/img/logo-barangay-trx-inspired.svg`
- Certificate logo is integrated into the certificate layout and print page.
